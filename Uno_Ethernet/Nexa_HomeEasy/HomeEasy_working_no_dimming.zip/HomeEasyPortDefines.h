#ifndef HomeEasyPortDefines_h
#define HomeEasyPortDefines_h

#define HEPORTA 0
#define HEPORTB 1
#define HEPORTC 2
#define HEPORTD 3
#define HEPORTE 4
#define HEPORTF 5
#define HEPORTG 6
#define HEPORTH 7
#define HEPORTI 8
#define HEPORTJ 9
#define HEPORTK 10
#define HEPORTL 11

#endif // HomeEasyPortDefines_h